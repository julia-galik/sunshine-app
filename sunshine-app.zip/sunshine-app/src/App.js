import React, { useState } from 'react';

function App() {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState(null);

  const fetchWeather = async () => {
    const API_KEY = '384ec51bca121eba81a698e0a9075a22';
    try {
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${API_KEY}`
      );
      const data = await response.json();

      if (response.ok) {
        setWeather(data);
        setError(null);  
      } else {
        setWeather(null);
        setError(data.message);
      }
    } catch (err) {
      setWeather(null);
      setError('Nie udało się połączyć z serwerem. Spróbuj ponownie później.');
    }
  };

  const handleInputChange = (e) => {
    setCity(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetchWeather();
  };

  return (
    <div className="App">
      <h1>SunshineApp 🌞</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={city}
          onChange={handleInputChange}
          placeholder="Wpisz miasto"
        />
        <button type="submit">Sprawdź pogodę</button>
      </form>

      {error && <p style={{ color: 'red' }}>Błąd: {error}</p>} 

      {weather && weather.main && weather.weather && (
        <div>
          <h2>Pogoda w {weather.name}</h2>
          <p>Temperatura: {weather.main.temp}°C</p>
          <p>Opis: {weather.weather[0].description}</p>
          <img
            src={`http://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`}
            alt="ikona pogody"
          />
        </div>
      )}
    </div>
  );
}

export default App;
